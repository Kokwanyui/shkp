import boto3
import json
import os
import io
import google.auth
import pandas as pd
from google.cloud import storage
from datetime import datetime, timedelta
import tempfile
import gzip

def lambda_handler(event, context):
    env = event['env']
    region = 'ap-east-1'

    # Google Configuration
    loading_date = datetime.today().strftime('%Y%m%d')
    gcs_bucket_name = 'tpdt-ga-etl'
    gcs_full_load_prefix = 'bq_daily_report_history/bq_daily_report_'
    gcs_delta_load_prefix = 'bq_daily_report_' + loading_date + "/" + 'bq_daily_report_'

    if env == 'prod':
        bucket_name = "tpdt-ga"
        object_name = "tpdt_ga_raw"
        os.environ['GOOGLE_APPLICATION_CREDENTIALS'] = 'clientLibraryConfig-aws-thepoint-prod.json'
        os.environ['GOOGLE_CLOUD_PROJECT'] = 'the-point-app-and-web'
    else:
        bucket_name = "tpdt-ga-"+env
        object_name = "tpdt_ga_raw_"+env
        os.environ['GOOGLE_APPLICATION_CREDENTIALS'] = 'clientLibraryConfig-aws-thepoint-uat.json'
        os.environ['GOOGLE_CLOUD_PROJECT'] = 'the-point-app-and-web'

    # S3 connection
    s3 = boto3.resource('s3', region_name=region)

    # Delete All Files in S3
    clean_bucket = s3.Bucket(bucket_name)
    clean_prefix = f'{object_name}/'
    clean_bucket.objects.filter(Prefix=clean_prefix).delete()
    print(clean_prefix+' deleted')

    # Google Connection
    gcs_client = storage.Client()
    gcs_blobs = gcs_client.list_blobs(gcs_bucket_name, prefix=gcs_full_load_prefix)
    gcs_delta_blobs = gcs_client.list_blobs(gcs_bucket_name, prefix=gcs_delta_load_prefix)

    # Upload History Files from GCS to S3
    for blob in gcs_blobs:
        file_name = blob.name.split('/')[1].split('.')[0]
        folder_name = file_name.split('_')[3][:8]

        # Download the blob to a temporary file
        with tempfile.NamedTemporaryFile() as temp_file:
            blob.download_to_filename(temp_file.name)
            upload_bucket = s3.Bucket(bucket_name)
            upload_path = f"{object_name}/{folder_name}/{file_name}.gz"
            upload_bucket.upload_file(temp_file.name, upload_path)
            print(f"{upload_path} uploaded to S3")

    # Upload Delta Files from GCS to S3
    for delta_load in gcs_delta_blobs:
        file_name = delta_load.name.split('/')[1].split('.')[0]
        folder_name = delta_load.name.split('/')[1].split('_')[3][:8]

        # Download the blob to a temporary file
        with tempfile.NamedTemporaryFile() as temp_file:
            delta_load.download_to_filename(temp_file.name)
            upload_bucket = s3.Bucket(bucket_name)
            upload_path = f"{object_name}/{folder_name}/{file_name}.gz"
            upload_bucket.upload_file(temp_file.name, upload_path)
            print(f"{upload_path} uploaded to S3")
