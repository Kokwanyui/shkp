import pysftp
import hashlib
import os
import pandas as pd
import pymysql
from sqlalchemy import create_engine
import sqlalchemy
from datetime import datetime, timedelta, date
from stat import S_ISDIR, S_ISREG
import re
import tempfile
import secretsmanager

remotepath_list = []
remoteDir = r'/'
included_folder = ['fredal', 'keytop', 'skidata']

entry_folder_Name = 'entry'
invoice_folder_Name = 'invoice'
redemption_folder_Name = 'redemption'

mysql_entry_table_name = 'carpark_sftp_entry'
mysql_invoice_table_name = 'carpark_sftp_invoice'
mysql_redemption_table_name = 'carpark_sftp_redemption'
mysql_inserted_file_table_name = 'carpark_sftp_inserted_file'
mysql_table_replace_append = 'append'


def db02_connection():
    db02_host, db02_port, db02_user, db02_pw, db02_dbname = secretsmanager.get_db_secret('tpdt_db02')
    db02_rw_host = db02_host.replace('ro', 'rw')
    db02 = create_engine(f'mysql+pymysql://{db02_user}:{db02_pw}@{db02_rw_host}:{db02_port}/bi_dimension')
    return db02


def sftp_connection():
    host1, host2, port, username, password = secretsmanager.get_sftp_secret('tpdt_carpark_data_sftp')
    cnopts = pysftp.CnOpts()
    cnopts.hostkeys = None
    sftp = pysftp.Connection(host=host1, username=username, password=password, cnopts=cnopts)
    return sftp


def inserted_history_filename(db02):
    inserted_file_sql = '''select * from `carpark_sftp_inserted_file`;'''
    df = pd.read_sql_query(inserted_file_sql, db02)
    df['short_filename'] = df['filename'].apply(lambda x: x.split('/')[-1] if '/' in x else x)
    inserted_filename_list = df['short_filename'].tolist()
    return inserted_filename_list


def file_list_extraction(sftp, remoteDir, included_folder):

    sftp.cwd(remoteDir)

    for entry in sftp.listdir_attr(remoteDir):
        remotepath = remoteDir + "/" + entry.filename
        mode = entry.st_mode
        for folder in included_folder:
            if S_ISDIR(mode) and folder in remotepath:
                file_list_extraction(sftp, remotepath, included_folder)
            elif S_ISREG(mode) and folder in remotepath:
                remotepath_list.append(remotepath)

    return remotepath_list


def lambda_handler(event, context):

    db02 = db02_connection()
    sftp = sftp_connection()
    inserted_filename_list = inserted_history_filename(db02)
    remotepath_list = file_list_extraction(sftp, remoteDir, included_folder)
    remotepath_list = [value for value in remotepath_list if value.split('/')[-1] not in inserted_filename_list]
    remotepath_list = [value.replace('upload', 'imported') for value in remotepath_list]
    distinct_remotepath_list = list(set(remotepath_list))
    print(distinct_remotepath_list)

    for remotepath in distinct_remotepath_list:
        second_remotepath = remotepath.replace('imported', 'upload')
        try:
            with tempfile.NamedTemporaryFile() as temp_file:
                try:
                    sftp.get(remotepath, temp_file.name)
                    final_path = remotepath
                except:
                    sftp.get(second_remotepath, temp_file.name)
                    final_path = second_remotepath

                df = pd.read_csv(temp_file.name).assign(filename=final_path)
                df = df.reset_index()
                df['card_no'] = df['card_no'].astype(str)
                df['card_no'] = df['card_no'].apply(lambda x: hashlib.sha256(x.encode()).hexdigest())
                df['car_in_datetime'] = pd.to_datetime(df["car_in_datetime"], format="%d/%m/%Y %H:%M:%S")
                if 'car_out_datetime' in df.columns:
                    df['car_out_datetime'] = pd.to_datetime(df["car_out_datetime"], format="%d/%m/%Y %H:%M:%S")
                if 'redemption_datetime(By_CCC)' in df.columns:
                    df['redemption_datetime(By_CCC)'] = pd.to_datetime(df["redemption_datetime(By_CCC)"], format="%d/%m/%Y %H:%M:%S")
                if 'redemption_datetime' in df.columns:
                    df['redemption_datetime'] = pd.to_datetime(df["redemption_datetime"], format="%d/%m/%Y %H:%M:%S")
                if 'parked_minute' in df.columns:
                    df['parked_minute'] = df['parked_minute'].astype('float')
                if 'total_redeemed_minute' in df.columns:
                    df['total_redeemed_minute'] = df['total_redeemed_minute'].astype('float')
                if 'total_parking_fee' in df.columns:
                    df['total_parking_fee'] = df['total_parking_fee'].astype('float')
                if 'total_paid_minute' in df.columns:
                    df['total_paid_minute'] = df['total_paid_minute'].astype('float')
                if 'invoice_amount' in df.columns:
                    df['invoice_amount'] = df['invoice_amount'].astype('float')
                if 'redeemed_parking_fee' in df.columns:
                    df['redeemed_parking_fee'] = df['redeemed_parking_fee'].astype('float')
                if 'redeemed_minute' in df.columns:
                    df['redeemed_minute'] = df['redeemed_minute'].astype('float')
                df['last_update'] = datetime.now() + timedelta(hours=8)

                inserted_df = df[['filename', 'last_update']].copy().drop_duplicates()

                # insert the df to mysql
                if entry_folder_Name in remotepath:
                    try:
                        df.to_sql(
                                        mysql_entry_table_name,
                                        db02,
                                        index=False,
                                        if_exists=mysql_table_replace_append,
                                        dtype={
                                            'property_id': sqlalchemy.types.VARCHAR(length=256),
                                            'parking_entry_id': sqlalchemy.types.VARCHAR(length=256),
                                            'card_no': sqlalchemy.types.VARCHAR(length=64),
                                            'car_plate': sqlalchemy.types.VARCHAR(length=256),
                                            'member_id': sqlalchemy.types.VARCHAR(length=256),
                                            'car_in_datetime': sqlalchemy.types.DATETIME,
                                            'car_out_datetime': sqlalchemy.types.DATETIME,
                                            'car_type': sqlalchemy.types.VARCHAR(length=256),
                                            'parked_minute': sqlalchemy.types.FLOAT,
                                            'total_redeemed_minute': sqlalchemy.types.FLOAT,
                                            'total_parking_fee': sqlalchemy.types.FLOAT,
                                            'total_paid_minute': sqlalchemy.types.FLOAT,
                                            'filename': sqlalchemy.types.VARCHAR(length=256),
                                            'last_update': sqlalchemy.types.DATETIME
                                        }
                                    )

                        # insert the inserted file record to database
                        inserted_df.to_sql(
                                        mysql_inserted_file_table_name,
                                        db02,
                                        index=False,
                                        if_exists=mysql_table_replace_append,
                                        dtype={
                                            'filename': sqlalchemy.types.VARCHAR(length=256),
                                            'last_update': sqlalchemy.types.DATETIME
                                        }
                                    )

                        print(final_path + ' inserted')

                    except:
                        print('Failed to insert: ' + final_path)


                elif invoice_folder_Name in remotepath:
                    try:
                        df.to_sql(
                                        mysql_invoice_table_name,
                                        db02,
                                        index=False,
                                        if_exists=mysql_table_replace_append,
                                        dtype={
                                            'property_id': sqlalchemy.types.VARCHAR(length=256),
                                            'invoice_no': sqlalchemy.types.VARCHAR(length=256),
                                            'parking_entry_id': sqlalchemy.types.VARCHAR(length=256),
                                            'card_no': sqlalchemy.types.VARCHAR(length=64),
                                            'car_plate': sqlalchemy.types.VARCHAR(length=256),
                                            'member_id': sqlalchemy.types.VARCHAR(length=256),
                                            'car_in_datetime': sqlalchemy.types.DATETIME,
                                            'car_out_datetime': sqlalchemy.types.DATETIME,
                                            'redemption_datetime(By_CCC)': sqlalchemy.types.DATETIME,
                                            'shop_no': sqlalchemy.types.VARCHAR(length=256),
                                            'shop_category': sqlalchemy.types.VARCHAR(length=256),
                                            'shop_name': sqlalchemy.types.VARCHAR(length=256),
                                            'invoice_amount': sqlalchemy.types.FLOAT,
                                            'filename': sqlalchemy.types.VARCHAR(length=256),
                                            'last_update': sqlalchemy.types.DATETIME
                                        }
                                    )

                        # insert the inserted file record to database
                        inserted_df.to_sql(
                                        mysql_inserted_file_table_name,
                                        db02,
                                        index=False,
                                        if_exists=mysql_table_replace_append,
                                        dtype={
                                            'filename': sqlalchemy.types.VARCHAR(length=256),
                                            'last_update': sqlalchemy.types.DATETIME
                                        }
                                    )
                        print(final_path + ' inserted')

                    except:
                        print('Failed to insert: ' + final_path)

                elif redemption_folder_Name in remotepath:
                    try:
                        df.to_sql(
                                        mysql_redemption_table_name,
                                        db02,
                                        index=False,
                                        if_exists=mysql_table_replace_append,
                                        dtype={
                                            'property_id': sqlalchemy.types.VARCHAR(length=256),
                                            'parking_entry_id': sqlalchemy.types.VARCHAR(length=256),
                                            'card_no': sqlalchemy.types.VARCHAR(length=256),
                                            'car_plate': sqlalchemy.types.VARCHAR(length=256),
                                            'member_id': sqlalchemy.types.VARCHAR(length=256),
                                            'car_in_datetime': sqlalchemy.types.DATETIME,
                                            'car_out_datetime': sqlalchemy.types.DATETIME,
                                            'redemption_type': sqlalchemy.types.VARCHAR(length=256),
                                            'redemption_datetime': sqlalchemy.types.DATETIME,
                                            'redeemed_parking_fee': sqlalchemy.types.FLOAT,
                                            'redeemed_minute': sqlalchemy.types.FLOAT,
                                            'filename': sqlalchemy.types.VARCHAR(length=256),
                                            'last_update': sqlalchemy.types.DATETIME
                                        }
                                    )

                        # insert the inserted file record to database
                        inserted_df.to_sql(
                                        mysql_inserted_file_table_name,
                                        db02,
                                        index=False,
                                        if_exists=mysql_table_replace_append,
                                        dtype={
                                            'filename': sqlalchemy.types.VARCHAR(length=256),
                                            'last_update': sqlalchemy.types.DATETIME
                                        }
                                    )
                        print(final_path + ' inserted')

                    except:
                        print('Failed to insert: ' + final_path)
        except:
            print('Failed to insert: ' + remotepath)