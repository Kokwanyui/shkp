import boto3
import json


def get_sftp_secret(secret_name):
    region_name = 'ap-east-1'
    # Create a Secrets Manager client
    session = boto3.session.Session()
    client = session.client(
        service_name='secretsmanager',
        region_name=region_name
    )
    # get secret value
    response = client.get_secret_value(SecretId=secret_name)
    secret = json.loads(response['SecretString'])

    host1 = secret['host1']
    host2 = secret['host2']
    port = secret['port']
    username = secret['username']
    password = secret['password']

    return host1, host2, port, username, password


def get_db_secret(secret_name):
    region_name = 'ap-east-1'
    # Create a Secrets Manager client
    session = boto3.session.Session()
    client = session.client(
        service_name='secretsmanager',
        region_name=region_name
    )
    # get secret value
    response = client.get_secret_value(SecretId=secret_name)
    secret = json.loads(response['SecretString'])

    host = secret['host']
    port = secret['port']
    username = secret['username']
    password = secret['password']
    dbname = secret['dbname']

    return host, port, username, password, dbname