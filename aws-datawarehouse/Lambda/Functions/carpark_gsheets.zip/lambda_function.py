import boto3
import json
from google.oauth2.service_account import Credentials
from google.auth.transport.requests import AuthorizedSession
import gspread
import pandas as pd
import s3


def lambda_handler(event, context):
    sheet_url = event['gsheet_url']
    columns_renaming = event['columns_renaming']
    worksheet = event['worksheet']
    bucket = event['bucket_to_save']
    s3_path = event['path_name']

    # service account json
    client = boto3.client('secretsmanager',region_name='ap-east-1')
    response = client.get_secret_value(SecretId='tpdt_gsheet_service_account')
    service_account_json = json.loads(response['SecretString'])

    # google sheet auth
    scope = ['https://www.googleapis.com/auth/spreadsheets']
    credentials = Credentials.from_service_account_info(service_account_json)
    scoped_credentials = credentials.with_scopes(scope)
    gc = gspread.Client(auth=scoped_credentials)
    gc.session = AuthorizedSession(scoped_credentials)

    # get google sheet data
    sheet = gc.open_by_url(sheet_url)
    worksheet = sheet.worksheet(worksheet)

    df = pd.DataFrame(worksheet.get_all_records())
    df['count'] = 1
    df = df.rename(columns=columns_renaming)
    location_path = '/tmp/gsheet.csv'
    df.to_csv(location_path, header=True, index=False)

    # upload df to s3
    aws_s3 = s3.Client()
    aws_s3.upload(location_path, bucket, s3_path)


