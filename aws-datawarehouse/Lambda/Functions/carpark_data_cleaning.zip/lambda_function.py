import pysftp
import checking_list
import boto3
import json
import secretsmanager
import athena
import s3
import db02


def filter_list(full_list, excludes):
    s = set(excludes)
    return (x for x in full_list if x not in s)


def get_sftp_result(host, user, pw):
    cnopts = pysftp.CnOpts()
    cnopts.hostkeys = None

    checking_paths = checking_list.to_check()
    result = []

    with pysftp.Connection(host=host, username=user, password=pw, cnopts=cnopts) as sftp:
        print('SFTP Connected')
        for checking_path in checking_paths:
            try:
                sftp.cwd(checking_path)  # Switch to a remote directory
                directory_structure = sftp.listdir_attr()  # Obtain structure of the remote directory

                for attr in directory_structure:
                    result.append(attr.filename)
            except:
                pass
    print('files name extracted:', result[-5:], '.....')
    return result


def get_athena_result(env):
    # Athena Config
    bucket = 'tpdt-automation'
    database = 'tpdt_03automation'
    target_view = 'carpark_sftp_checking'
    s3_prefix = f'{target_view}/athena/'
    output_path = f's3://{bucket}/{s3_prefix}'
    query_string = f'Select * from {database}.{target_view}'

    # Get Parking data from Athena
    aws_athena = athena.Client()
    aws_s3 = s3.Client()

    aws_s3.clean_with_prefix(bucket, s3_prefix)
    s3_path = aws_athena.execute(query_string, env, output_path)
    athena_df = aws_s3.read_csv(bucket, s3_path)
    athena_files = athena_df['file'].to_list()
    print('athena extraction:', s3_path)
    return athena_files


def download_missed_files(targets, host, user, pw, bucket, s3_prefix):
    aws_s3 = s3.Client()
    aws_s3.clean_with_prefix(bucket, s3_prefix)

    cnopts = pysftp.CnOpts()
    cnopts.hostkeys = None

    with pysftp.Connection(host=host, username=user, password=pw, cnopts=cnopts) as sftp:
        for target in targets:
            if len(target.split('-')) >= 2:
                folder = target.split('-')[0]
                subfolder = target.split('-')[1]
                filepath = f'{folder}/{subfolder}/{target}'

                # get full path
                if filepath.startswith('mp/'):
                    staging_path = f'/skidata/upload/{filepath}'
                    full_path = staging_path.replace('mp/', 'metroplaza/')
                elif filepath.startswith('epc/'):
                    full_path = f'/keytop/upload/{filepath}'
                elif filepath.startswith('moko/'):
                    full_path = f'/fredal/upload/{filepath}'
                else:
                    full_path = f'/skidata/upload/{filepath}'

                second_path = full_path.replace('upload', 'imported')

                # download missed file to s3
                location_path = f'/tmp/{target}'
                s3_path = f'{s3_prefix}/{target}'

                try:
                    sftp.get(full_path, location_path)
                    aws_s3.upload(location_path, bucket, s3_path)
                except:
                    try:
                        sftp.get(second_path, location_path)
                        aws_s3.upload(location_path, bucket, s3_path)
                    except:
                        pass
            else:
                pass


def lambda_handler(event, context):
    env = event['env']

    host1, host2, port, user, pw = secretsmanager.get_sftp_secret('tpdt_carpark_data_sftp')
    aws_s3 = s3.Client()
    sql = db02.Connect()

    # find all sftp files name in checking path
    sftp_files = get_sftp_result(host1, user, pw)
    unique_sftp_files = list(dict.fromkeys(sftp_files))

    # find all athena records
    athena_files = get_athena_result(env)

    # missed file in athena
    missed_files = list(filter_list(unique_sftp_files, athena_files))
    if len(missed_files) == 0:
        print('all files captured')
    else:
        print(f'missed files: {missed_files}')

    s3_staging_bucket = 'tpdt-automation'
    s3_prefix = 'carpark_sftp_checking/sftp'
    download_missed_files(missed_files, host1, user, pw, s3_staging_bucket, s3_prefix)
    s3_objects = aws_s3.list_objects_with_prefix(s3_staging_bucket, s3_prefix)

    for s3_object in s3_objects:
        s3_object_path = s3_object['Key']
        insert_type = s3_object_path.split('-')[1]

        try:
            if insert_type == 'entry':
                db_response = sql.insert_entry(s3_object_path)
            elif insert_type == 'invoice':
                db_response = sql.insert_invoice(s3_object_path)
            elif insert_type == 'redemption':
                db_response = sql.insert_redemption(s3_object_path)
            else:
                db_response = f'{s3_object_path} not inserted, please review insert type'
                pass
        except:
            db_response = f'{s3_object_path} not inserted, please review insert type'

        print(db_response)



















