from sqlalchemy import create_engine
import secretsmanager
import s3
import pandas as pd
import io


class Connect(object):
    def __init__(self):
        host, port, user, pw, dbname = secretsmanager.get_db_secret('tpdt_db02')
        rw_host = host.replace('ro', 'rw')
        self.connection = create_engine(f'mysql+pymysql://{user}:{pw}@{rw_host}:{port}/bi_dimension')
        self.bucket = 'tpdt-automation'

    def insert_entry(self, csv_path):
        aws_s3 = s3.Client()
        df = aws_s3.read_csv(self.bucket, csv_path)

        # data cleaning
        df.rename(columns={'total_redeemed_minute': 'total_redeem_minute'}, inplace=True)
        df['car_in_datetime'] = pd.to_datetime(df['car_in_datetime'], dayfirst=True).dt.strftime('%Y-%m-%d %H:%M:%S')
        df['car_out_datetime'] = pd.to_datetime(df['car_out_datetime'], dayfirst=True).dt.strftime('%Y-%m-%d %H:%M:%S')
        df['row_no'] = 9999999999
        df['file_name'] = csv_path

        # re-order columns
        columns_order = ['row_no', 'car_in_datetime', 'car_out_datetime', 'car_plate', 'car_type',
                         'card_no', 'member_id', 'parked_minute', 'parking_entry_id',
                         'property_id', 'total_paid_minute', 'total_parking_fee',
                         'total_redeem_minute', 'file_name']
        adjusted_df = df[columns_order]

        # insert into mysql, table: missed_carpark_sftp_entry
        db02 = self.connection
        adjusted_df.to_sql('missed_carpark_sftp_entry', db02, index=False, if_exists='append')
        return f'{csv_path} inserted into missed_carpark_sftp_entry. Method: append'

    def insert_invoice(self, csv_path):
        aws_s3 = s3.Client()
        df = aws_s3.read_csv(self.bucket, csv_path)

        # data cleaning
        df.rename(columns={'redemption_datetime(By_CCC)': 'redemption_datetime'}, inplace=True)
        df['car_in_datetime'] = pd.to_datetime(df['car_in_datetime'], dayfirst=True).dt.strftime('%Y-%m-%d %H:%M:%S')
        df['car_out_datetime'] = pd.to_datetime(df['car_out_datetime'], dayfirst=True).dt.strftime('%Y-%m-%d %H:%M:%S')
        df['redemption_datetime'] = pd.to_datetime(df['redemption_datetime'], dayfirst=True).dt.strftime(
            '%Y-%m-%d %H:%M:%s')
        df['row_no'] = 9999999999
        df['file_name'] = csv_path

        # re-order columns
        columns_order = ['row_no', 'car_in_datetime', 'car_out_datetime', 'car_plate', 'card_no',
                         'invoice_amount', 'invoice_no', 'member_id', 'parking_entry_id',
                         'property_id', 'redemption_datetime', 'shop_category', 'shop_name', 'shop_no', 'file_name']
        adjusted_df = df[columns_order]

        # insert into mysql, table: missed_carpark_sftp_invoice
        db02 = self.connection
        adjusted_df.to_sql('missed_carpark_sftp_invoice', db02, index=False, if_exists='append')
        return f'{csv_path} inserted into missed_carpark_sftp_invoice. Method: append'

    def insert_redemption(self, csv_path):
        aws_s3 = s3.Client()
        df = aws_s3.read_csv(self.bucket, csv_path)

        # data cleaning
        df['car_in_datetime'] = pd.to_datetime(df['car_in_datetime'], dayfirst=True).dt.strftime('%Y-%d-%m %H:%M:%S')
        df['car_out_datetime'] = pd.to_datetime(df['car_out_datetime'], dayfirst=True).dt.strftime('%Y-%d-%m %H:%M:%S')
        df['redemption_datetime'] = pd.to_datetime(df['redemption_datetime'], dayfirst=True).dt.strftime(
            '%Y-%d-%m %H:%M:%s')
        df['row_no'] = 9999999999
        df['file_name'] = csv_path

        # re-order columns
        columns_order = ['row_no', 'car_in_datetime', 'car_out_datetime', 'car_plate', 'card_no',
                         'member_id', 'parking_entry_id', 'property_id', 'redeemed_minute',
                         'redeemed_parking_fee', 'redemption_datetime', 'redemption_type', 'file_name']
        adjusted_df = df[columns_order]

        # insert into mysql, table: missed_carpark_sftp_redemption
        db02 = self.connection
        adjusted_df.to_sql('missed_carpark_sftp_redemption', db02, index=False, if_exists='append')
        return f'{csv_path} inserted into missed_carpark_sftp_redemption. Method: append'
