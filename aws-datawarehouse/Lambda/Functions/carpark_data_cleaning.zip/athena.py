import boto3
import json
import time
from datetime import date


class Client(object):
    def __init__(self):
        self.client = boto3.client('athena')

    def get_path(self, athena_execution_id, max_execution_time=5):
        athena_client = self.client
        state = 'RUNNING'

        while (max_execution_time > 0) & (state in ['RUNNING', 'QUEUED']):
            max_execution_time = max_execution_time - 1
            response = athena_client.get_query_execution(QueryExecutionId=athena_execution_id)

            if 'QueryExecution' in response and 'Status' in response['QueryExecution'] and 'State' in \
                    response['QueryExecution']['Status']:
                state = response['QueryExecution']['Status']['State']
                if state == 'FAILED':
                    return json.loads(json.dumps(response, default=str))
                elif state == 'SUCCEEDED':
                    s3_path = response['QueryExecution']['ResultConfiguration']['OutputLocation']
                    return s3_path
            time.sleep(10)

    def execute(self, script, env, output_path):
        athena_client = self.client

        if env == 'prod':
            athena_db = 'tpdt_automation'
        else:
            athena_db = f'tpdt_automation_{env}'

        execution_id = athena_client.start_query_execution(
            QueryString=script,
            QueryExecutionContext={
                'Database': athena_db
            },
            ResultConfiguration={
                'OutputLocation': output_path,
            }
        )['QueryExecutionId']

        file_path = self.get_path(execution_id)
        return file_path

