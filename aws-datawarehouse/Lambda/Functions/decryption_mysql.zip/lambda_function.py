import pandas as pd
from sqlalchemy import create_engine
import time
from datetime import date, timedelta
import secretsmanager


def lambda_handler(event, context):
    host, port, user, password, dbname = secretsmanager.get_db_secret('tpdt_db02')
    today = date.today()
    p7d = today - timedelta(days=7)
    p7d_string = p7d.strftime('%Y-%m-%d')

    # get member info
    vip_bi = create_engine(f'mysql+pymysql://{user}:{password}@{host}:{port}/{dbname}')

    query = f"""Select id, email, phone, member_id from shkpmalls_vip_bi.member where date(update_date) >= '{p7d_string}'"""
    df = pd.read_sql_query(query, vip_bi)
    rows = len(df.index)
    print(f'numbers of member to decrypt: {rows}')

    # truncate into datamart table
    datamart_host = host.replace('ro', 'rw')
    datamart = create_engine(f'mysql+pymysql://{user}:{password}@{datamart_host}:{port}/bi_datamart')

    try:
        datamart.connect().execute("truncate table decrypted_member_info")
        print('decrypted_member_info truncated')
    except:
        pass

    df.to_sql('member', datamart, index=False, if_exists='replace')
    print(f'data inserted into bi_datamart.member')
