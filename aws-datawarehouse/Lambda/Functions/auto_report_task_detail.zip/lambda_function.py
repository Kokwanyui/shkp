import boto3
import json
from sqlalchemy import create_engine
import sqlalchemy
import pandas as pd
import secretsmanager
import os


def lambda_handler(event, context):
    # Initialize
    env = os.environ['environment']
    task = event['task']

    if (env == 'dev') | (env == 'uat'):
        # Extract task information from DynamoDB
        client = boto3.client('dynamodb')
        details = client.get_item(TableName='tpdt_automation_tasks',
                                  Key={'task': {'S': task}})

        views_name = details['Item']['views_name']['S']
        bucket = details['Item']['result_bucket']['M'][env]['S']
        folder = details['Item']['result_folder']['S']
        owners = details['Item']['owners']['S']
        sns_topic = details['Item']['sns_topic']['S']
        expiry_date = details['Item']['expiry_date']['S']
        additional_msg = details['Item']['additional_msg']['S']
    else:
        # Extract DB02 secret
        host, port, dbname, user, pw = secretsmanager.get_secret('tpdt_db02')
        connection = create_engine(f'mysql+pymysql://{user}:{pw}@{host}:{port}/{dbname}')

        # Extract task information from DB02
        sql = f"Select * from bi_dimension.automation_job_config where task = '{task}' and env = '{env}'"
        details = pd.read_sql_query(sql, connection)

        views_name = str(details.iloc[0]['views_name'])
        bucket = str(details.iloc[0]['result_bucket'])
        folder = str(details.iloc[0]['result_folder'])
        owners = str(details.iloc[0]['owners'])
        sns_topic = str(details.iloc[0]['sns_topic'])
        expiry_date = str(details.iloc[0]['expiry_date'])
        additional_msg = str(details.iloc[0]['additional_msg'])


    # Genereate Response Json
    response_json = {
        'env': env,
        'task': task,
        'views_name': views_name,
        'bucket': bucket,
        'folder': folder,
        'owners': owners,
        'sns_topic': sns_topic,
        'expiry_date': expiry_date,
        'additional_msg': additional_msg
        }
    return response_json
