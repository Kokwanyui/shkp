import boto3
import json


def get_secret(secretid):
    client = boto3.client('secretsmanager')
    response = client.get_secret_value(SecretId=secretid)
    secret = json.loads(response['SecretString'])

    host = secret['host']
    port = secret['port']
    dbname = secret['dbname']
    username = secret['username']
    password = secret['password']

    return host, port, dbname, username, password
