import json
import boto3
import os


def sns_publish(sns_topic, email_subject, email_msg):
    # identify environment account number
    if os.environ['environment'] == 'dev':
        account = '214369837568'
    elif os.environ['environment'] == 'uat':
        account = '581813634934'
    else:
        account = '244353132907'

    # publish sns
    client = boto3.client('sns')
    snsarn = f'arn:aws:sns:ap-east-1:{account}:{sns_topic}'
    response = client.publish(
        TopicArn=snsarn,
        Message=email_msg,
        Subject=email_subject)
    return response


def lambda_handler(event, context):
    task = event['task']
    result_path = event['Saved In/ Error Msg']
    extraction_status = event['extraction_status']
    task_owner = event['task_owner']
    sns_topic = event['sns_topic']
    expiry_date = event['expiry_date']
    additional_msg = event['additional_msg']

    if sns_topic == 'None':
        response = {'Run': 'no need sns'}

    elif extraction_status == 'Success':
        subject = f'[Automated Report] {task}'
        topic = f'tpdt_{task}'

        message = """
        Hi Report Users,

        Please find below link for automated report({report_name}):
        {result_path}

        if any issue related to this data request, please email:
        {task_owner}

        IMPORTANT NOTES:
        {msg}
                
        This automation will be expired in {expiry}. 
        Data Team will evaluate if automation continues after expiry date.
                
        Thanks,
        The Point Data Team
        """.format(report_name=task, result_path=result_path, task_owner=task_owner, msg=additional_msg, expiry=expiry_date)
        response = sns_publish(topic, subject, message)

    else:
        response = {'Run': 'no sns sent'}

    return response
