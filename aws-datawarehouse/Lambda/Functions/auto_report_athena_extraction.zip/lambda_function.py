import json
import athena
import os
from datetime import datetime, timedelta, date
import logging
import boto3

logger = logging.getLogger()
logger.setLevel(logging.INFO)


def renaming_object(bucket, folder, task_name, existing_path):
    today = date.today()
    copysource = existing_path.replace('s3://', '')
    copysource_key = copysource.replace(f'{bucket}/', '')
    copysource_key_metadata = copysource_key + '.metadata'

    today_string = today.strftime("%Y%m%d")
    new_file_key = f'{folder}/{today_string}/{task_name}_{today_string}.csv'

    if (bucket == 'tpdt-adobe') or (bucket == 'tpdt-adobe-dev') or (bucket == 'tpdt-adobe-uat'):
        region = 'ap-southeast-1'
    else:
        region = 'ap-east-1'

    # move file and rename
    rename_file = boto3.resource('s3')
    rename_file.Object(bucket, new_file_key).copy_from(CopySource=copysource)
    rename_file.Object(bucket, copysource_key).delete()
    rename_file.Object(bucket, copysource_key_metadata).delete()
    return f'https://s3.console.aws.amazon.com/s3/buckets/{bucket}?region={region}&prefix={folder}/{today_string}/&showversions=false'


def lambda_handler(event, context):
    # Initialize
    env = event['env']
    task = event['task']
    views_name = event['views_name']
    bucket = event['bucket']
    folder = event['folder']
    owners = event['owners']
    sns_topic = event['sns_topic']
    expiry_date = event['expiry_date']
    additional_msg = event['additional_msg']

    # Get final query
    final_query = f'Select * from {views_name}'

    # Execute query in Athena and Rename
    sql = athena.Client()
    saved_path = sql.execute(final_query, env, bucket, folder)
    print(saved_path)
    if saved_path.startswith('s3:'):
        final_path = renaming_object(bucket, folder, task, saved_path)
        extraction_status = 'Success'
    else:
        final_path = saved_path
        extraction_status = 'Fail'
    logger.info(f'Saved In/ Error Msg: {final_path}')

    # Generate Response Json
    now = datetime.now() + timedelta(hours=8)
    response_body = {
        'task': task,
        'Saved In/ Error Msg': final_path,
        'extraction_status': extraction_status,
        'task_owner': owners,
        'Execution_time': now.strftime("%Y-%m-%d %H:%M:%S"),
        'sns_topic': sns_topic,
        'expiry_date': expiry_date,
        'additional_msg': additional_msg
    }

    # Response
    return response_body
