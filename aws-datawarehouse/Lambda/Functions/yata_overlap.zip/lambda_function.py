import json
import boto3
import logging
import os

logger = logging.getLogger()
logger.setLevel(logging.INFO)


def get_secret(secret_name):
    region_name = 'ap-east-1'

    # Create a Secrets Manager client
    session = boto3.session.Session()
    client = session.client(
        service_name='secretsmanager',
        region_name=region_name
    )

    # get secret value
    response = client.get_secret_value(SecretId=secret_name)
    secret = json.loads(response['SecretString'])

    key = secret['cdp_prod_key']
    secret_key = secret['cdp_secret_access']

    return key, secret_key


def save_to_tpdt(source_object, env, bucket, location):
    # Create a tpdt S3 client
    tpdt_s3 = boto3.client('s3')

    if env == 'prod':
        dest_bucket = bucket
    else:
        dest_bucket = f'{bucket}-{env}'
    logging.info(f'result saved to bucket: {dest_bucket}')
    tpdt_s3.upload_fileobj(source_object['Body'], dest_bucket, location)


def get_yata_overlap_member(cdp_key, cdp_secret_key, cdp_bucket_name, cdp_prefix_name):
    # Create a cdp S3 client
    cdp_s3 = boto3.client('s3',
                          region_name='ap-east-1',
                          aws_access_key_id=cdp_key,
                          aws_secret_access_key=cdp_secret_key)

    # Find all overlap member objects
    objects = cdp_s3.list_objects_v2(Bucket=cdp_bucket_name, Prefix=cdp_prefix_name)['Contents']

    # Find last modified object
    object_dict = {}
    for object in objects:
        file = object['Key']
        modified_time = object['LastModified']
        object_dict[file] = modified_time

    sorted_object_dict = {k: v for k, v in sorted(object_dict.items(), key=lambda item: item[1], reverse=True)}
    last_modified_object = list(sorted_object_dict.keys())[0]

    # copy data
    source_object = cdp_s3.get_object(Bucket=cdp_bucket_name, Key=last_modified_object)
    logging.info(f'file extracted: {source_object}')
    return source_object


def lambda_handler(event, context):
    # Config
    env = event['env']
    secret_name = os.environ.get('secret_name')
    cdp_bucket = os.environ.get('cdp_bucket')
    cdp_prefix = os.environ.get('cdp_prefix')
    tpdt_bucket = os.environ.get('tpdt_bucket')
    tpdt_location = os.environ.get('tpdt_location')

    # ToDo
    cdp_key, cdp_secret_key = get_secret(secret_name)
    overlap_member = get_yata_overlap_member(cdp_key, cdp_secret_key, cdp_bucket, cdp_prefix)
    save_to_tpdt(overlap_member, env, tpdt_bucket, tpdt_location)

