import boto3
import json
import os
import io
import google.auth
import pandas as pd
from google.cloud import storage
from datetime import datetime, timedelta
import tempfile
import gzip

def lambda_handler(event, context):
    env = event['env']
    region = 'ap-east-1'

    # Google Configuration
    loading_date = datetime.today().strftime('%Y%m%d')
    clean_date = (datetime.today() - timedelta(days=1)).strftime('%Y%m%d')
    gcs_bucket_name = 'tpdt-ga-etl'
    gcs_filename_prefix = 'bq_daily_report_'
    gcs_directory_path = gcs_filename_prefix + loading_date + "/" + gcs_filename_prefix
    gcs_clean_directory_path = gcs_filename_prefix + clean_date + "/"

    if env == 'prod':
        bucket_name = "tpdt-ga"
        object_name = "tpdt_ga_raw"
        os.environ['GOOGLE_APPLICATION_CREDENTIALS'] = 'clientLibraryConfig-aws-thepoint-prod.json'
        os.environ['GOOGLE_CLOUD_PROJECT'] = 'the-point-app-and-web'
    else:
        bucket_name = "tpdt-ga-"+env
        object_name = "tpdt_ga_raw_"+env
        os.environ['GOOGLE_APPLICATION_CREDENTIALS'] = 'clientLibraryConfig-aws-thepoint-uat.json'
        os.environ['GOOGLE_CLOUD_PROJECT'] = 'the-point-app-and-web'

    # S3 connection
    s3 = boto3.resource('s3', region_name=region)

    # Google Connection
    gcs_client = storage.Client()
    gcs_blobs = gcs_client.list_blobs(gcs_bucket_name, prefix=gcs_directory_path)
    gcs_blobs_deletion = gcs_client.list_blobs(gcs_bucket_name, prefix=gcs_directory_path)
    gcs_clean_blobs = gcs_client.list_blobs(gcs_bucket_name, prefix=gcs_clean_directory_path)

    # Delete Delta Files in S3
    for delta_dates in gcs_blobs_deletion:
        date_string = delta_dates.name.split('/')[1].split('_')[3][:8]
        clean_bucket = s3.Bucket(bucket_name)
        clean_prefix = f'{object_name}/{date_string}/'
        clean_bucket.objects.filter(Prefix=clean_prefix).delete()
        print(clean_prefix+' deleted')

    # Delete yesterday bucket in GCS
    for clean_bucket in gcs_clean_blobs:
        clean_bucket.delete()
        print(f"Object gs://{gcs_bucket_name}/{clean_bucket} deleted")

    # Upload Delta Files from GCS to S3
    for blob in gcs_blobs:
        file_name = blob.name.split('/')[1].split('.')[0]
        folder_name = blob.name.split('/')[1].split('_')[3][:8]

        # Download the blob to a temporary file
        with tempfile.NamedTemporaryFile() as temp_file:
            blob.download_to_filename(temp_file.name)
            upload_bucket = s3.Bucket(bucket_name)
            upload_path = f"{object_name}/{folder_name}/{file_name}.gz"
            upload_bucket.upload_file(temp_file.name, upload_path)
            print(f"{upload_path} uploaded to S3")
