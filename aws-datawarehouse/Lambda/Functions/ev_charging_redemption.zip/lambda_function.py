import boto3
import pandas as pd
from datetime import datetime, timedelta
import secretsmanager
from sqlalchemy import create_engine
import sqlalchemy
import pymysql
import tempfile

def lambda_handler(event, context):
    env = event['env']
    region = 'ap-east-1'
    file_name = 'staging_ev_charging_redemption'
    sql = '''SELECT bonus_points_transaction_id, created_date as created_datetime, mall_id, member_id, points, updated_date FROM shkpmalls_vip.`bonus_points_transaction` where adjust_reason_lang1 = 'Redeem for the EV charging fee' and date(created_date) < current_date();'''

    if env == 'prod':
        bucket_name = "tpdt-staging"
        object_name = "tpdt_staging_ev_charging_redemption"
    else:
        bucket_name = "tpdt-staging-"+env
        object_name = "tpdt_staging_ev_charging_redemption"+env

    # S3 connection
    s3 = boto3.client('s3', region_name=region)

    # DB01 connection
    db01_host, db01_port, db01_user, db01_pw, db01_dbname = secretsmanager.get_db_secret('tpdt_db01')
    db01 = create_engine(f'mysql+pymysql://{db01_user}:{db01_pw}@{db01_host}:{db01_port}/{db01_dbname}')

    # extract data from DB01 and put it in S3
    df = pd.read_sql_query(sql, db01)
    df['created_datetime'] = pd.to_datetime(df['created_datetime'])
    df['updated_date'] = pd.to_datetime(df['updated_date'])
    csv_data = df.to_csv(index=False)
    s3.put_object(Body=csv_data, Bucket=bucket_name, Key=f"{object_name}/{file_name}.csv")

