from Crypto.Cipher import AES
import base64
import hashlib


class AESCrypt(object):
    def __init__(self, secret_key):
        self.BLOCK_SIZE = 16
        self.key = hashlib.sha256(secret_key.encode()).digest()

    def pkcs7_pad(self, s):
        length = self.BLOCK_SIZE - (len(s) % self.BLOCK_SIZE)
        s += bytes([length]) * length
        return s

    def pkcs7_unpad(self, s):
        """
        unpadding according to PKCS #7
        @param s: string to unpad
        @type s: byte
        @rtype: byte
        """
        sd = -(s[-1])
        return s[0:sd]

    def encrypt(self, plain_text):
        if (plain_text is None) or (len(plain_text) == 0):
            raise ValueError('input text cannot be null or empty set')

        plain_bytes = plain_text.encode('utf-8')
        raw = self.pkcs7_pad(plain_bytes)
        cipher = AES.new(self.key, AES.MODE_ECB)
        cipher_bytes = cipher.encrypt(raw)
        cipher_text = self.base64_encode(cipher_bytes)
        return cipher_text

    def decrypt(self, cipher_text):
        cipher_bytes = self.base64_decode(cipher_text)
        cipher = AES.new(self.key, AES.MODE_ECB)
        plain_pad = cipher.decrypt(cipher_bytes)
        plain_text = self.pkcs7_unpad(plain_pad)
        return plain_text.decode()

    def base64_encode(self, bytes_data):
        """
        加base64
        :type bytes_data: byte
        :rtype 返回类型: string
        """
        return (base64.urlsafe_b64encode(bytes_data)).decode()

    def base64_decode(self, str_data):
        """
        解base64
        :type str_data: string
        :rtype 返回类型: byte
        """
        return base64.urlsafe_b64decode(str_data)



