import pandas as pd
import crypto
from sqlalchemy import create_engine
import boto3
import secretsmanager
import json
import io

key = secretsmanager.get_encryption_key()
aes = crypto.AESCrypt(key)
s3 = boto3.client('s3', region_name='ap-east-1')


def lambda_handler(event, context):
    host, port, username, password, dbname = secretsmanager.get_db_secret('tpdt_db02')
    rw_host = host.replace('ro', 'rw')
    datamart = create_engine(f'mysql+pymysql://{username}:{password}@{rw_host}:{port}/bi_datamart')
    query = "Select *, concat('SHKP', LPAD(id, 7, 0)) as member_id from decrypted_member_info"
    df = pd.read_sql_query(query, datamart)

    # encryption
    df['encrypted_phone'] = df['phone'].apply(lambda x: aes.encrypt(str(x)))
    df['encrypted_email'] = df['email'].apply(lambda x: aes.encrypt(str(x)))

    # drop columns
    df = df.drop(columns=['phone', 'email'])

    # concat with previous data
    previous_data = "Select *, concat('SHKP', LPAD(id, 7, 0)) as member_id from decrypted_member_info"
    dimension = create_engine(f'mysql+pymysql://{username}:{password}@{rw_host}:{port}/bi_dimension')
    previous_df = pd.read_sql_query(previous_data, dimension)
    final_df = pd.concat([df, previous_df], ignore_index=True).drop_duplicates().reset_index(drop=True)

    # save new df to S3
    location_path = '/tmp/member_info.csv'
    final_df.to_csv(location_path, header=True, index=False)
    s3.upload_file(location_path, bucket, object_key)

    row_count = len(final_df.index)
    print(f'new member info save into {bucket}/{object_key}, rows: {row_count}')

    datamart.connect().execute("truncate table decrypted_member_info")
    print('decrypted_member_info truncated')
